# Cursed Fate: Toon Force (addon)

Forge 1.20.1 addon. Adds the **Toon Force Tome** (Tools & Utilities creative tab).
Right-click uses the selected gag. Sneak + right-click cycles gags.

Gags: Painted Door, Anvil Drop, Dynamite Bundle, Boxing Glove, Gravity Gag,
Fourth Wall Break, and the Domain "That's All Folks".

## Get the jar from GitHub (no installs)
1. Make a free GitHub account and create a new repository.
2. Upload everything in this folder, including the `.github` folder.
   (If `.github/workflows/build.yml` doesn't show up, use Add file > Create new file,
   type `.github/workflows/build.yml` as the name and paste in the contents of build.yml.)
3. Open the Actions tab, wait for "Build jar" to go green.
4. Open the finished run and download `toonforce-jar` under Artifacts. Unzip it
   to get the jar, then put the jar in your mods folder.

## Notes
- Cursed energy cost is a stub in CursedFateHook.java. Nothing is charged yet.
- Not compiled or tested by the author. Report any build errors.
