package com.example.toonforce;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/**
 * Sneak + right-click: cycle gag. Right-click: use the selected gag.
 */
public class ToonTomeItem extends Item {
    private static final String TAG = "Ability";

    public ToonTomeItem(Properties properties) {
        super(properties);
    }

    private static int getAbilityIndex(ItemStack stack) {
        int i = stack.hasTag() ? stack.getTag().getInt(TAG) : 0;
        int n = ToonAbility.values().length;
        return ((i % n) + n) % n;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        if (player.isShiftKeyDown()) {
            if (!level.isClientSide) {
                int next = (getAbilityIndex(stack) + 1) % ToonAbility.values().length;
                stack.getOrCreateTag().putInt(TAG, next);
                player.displayClientMessage(
                        Component.literal("Gag: " + ToonAbility.values()[next].displayName), true);
            }
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }

        if (player.getCooldowns().isOnCooldown(this)) {
            return InteractionResultHolder.fail(stack);
        }
        if (level.isClientSide) {
            return InteractionResultHolder.success(stack);
        }

        ToonAbility ability = ToonAbility.values()[getAbilityIndex(stack)];
        if (!CursedFateHook.tryConsumeCursedEnergy(player, ability.cost)) {
            player.displayClientMessage(Component.literal("Not enough cursed energy."), true);
            return InteractionResultHolder.fail(stack);
        }

        boolean ok = ToonAbilities.run(ability, (ServerLevel) level, player);
        if (!ok) {
            return InteractionResultHolder.fail(stack);
        }

        player.getCooldowns().addCooldown(this, ability.cooldown);
        player.displayClientMessage(Component.literal(ability.comicWord), true);
        return InteractionResultHolder.success(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level,
                                List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("Gag: " + ToonAbility.values()[getAbilityIndex(stack)].displayName));
        tooltip.add(Component.literal("Right-click: use"));
        tooltip.add(Component.literal("Sneak + right-click: change gag"));
    }
}
