package com.example.toonforce;

import net.minecraft.world.entity.player.Player;

/**
 * The ONLY place that touches Cursed Fate's internals. Cursed Fate has no
 * published addon API, so this is a stub that always allows the ability.
 * To charge real cursed energy, find Cursed Fate's energy class in its jar
 * and call it here.
 */
public final class CursedFateHook {
    private CursedFateHook() {}

    public static boolean tryConsumeCursedEnergy(Player player, int amount) {
        // TODO: replace with Cursed Fate's cursed-energy capability.
        return true;
    }
}
