package com.example.toonforce;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/** The actual gag logic. All of this runs on the server. */
public final class ToonAbilities {
    private ToonAbilities() {}

    public static boolean run(ToonAbility ability, ServerLevel level, Player player) {
        switch (ability) {
            case PAINTED_DOOR:  return paintedDoor(level, player);
            case ANVIL_DROP:    return anvilDrop(level, player);
            case DYNAMITE:      return dynamite(level, player);
            case BOXING_GLOVE:  return boxingGlove(level, player);
            case GRAVITY_GAG:   return gravityGag(level, player);
            case FOURTH_WALL:   return fourthWall(level, player);
            case DOMAIN:        return domain(level, player);
            default:            return false;
        }
    }

    // ---- helpers ---------------------------------------------------------

    private static boolean isFree(Level level, BlockPos feet) {
        return level.getBlockState(feet).getCollisionShape(level, feet).isEmpty()
                && level.getBlockState(feet.above()).getCollisionShape(level, feet.above()).isEmpty();
    }

    private static boolean hasFloor(Level level, BlockPos feet) {
        BlockPos below = feet.below();
        return !level.getBlockState(below).getCollisionShape(level, below).isEmpty();
    }

    private static LivingEntity findTarget(ServerLevel level, Player player, double range) {
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        AABB box = player.getBoundingBox().expandTowards(look.scale(range)).inflate(2.0);
        List<LivingEntity> list = level.getEntitiesOfClass(LivingEntity.class, box,
                e -> e != player && e.isAlive() && !e.isSpectator());
        LivingEntity best = null;
        double bestDot = 0.9;
        for (LivingEntity e : list) {
            Vec3 to = e.getEyePosition().subtract(eye);
            double dist = to.length();
            if (dist > range || dist < 0.1) continue;
            double dot = to.normalize().dot(look);
            if (dot > bestDot) {
                bestDot = dot;
                best = e;
            }
        }
        return best;
    }

    private static void puff(ServerLevel level, ParticleOptions type, double x, double y, double z, int count) {
        level.sendParticles(type, x, y, z, count, 0.4, 0.5, 0.4, 0.05);
    }

    private static void sound(ServerLevel level, double x, double y, double z, SoundEvent s, float pitch) {
        level.playSound(null, x, y, z, s, SoundSource.PLAYERS, 1.0f, pitch);
    }

    private static void fail(Player player, String msg) {
        player.displayClientMessage(Component.literal(msg), true);
    }

    // ---- gags ------------------------------------------------------------

    /** Paint a door on a wall and walk through it to the other side. */
    private static boolean paintedDoor(ServerLevel level, Player player) {
        Vec3 look = player.getLookAngle();
        Vec3 dir = new Vec3(look.x, 0, look.z);
        if (dir.lengthSqr() < 1.0E-4) {
            fail(player, "Look at a wall.");
            return false;
        }
        dir = dir.normalize();

        boolean passedSolid = false;
        for (int i = 1; i <= 12; i++) {
            BlockPos feet = BlockPos.containing(
                    player.getX() + dir.x * i, player.getY(), player.getZ() + dir.z * i);
            if (!isFree(level, feet)) {
                passedSolid = true;
                continue;
            }
            if (passedSolid && hasFloor(level, feet)) {
                puff(level, ParticleTypes.POOF, player.getX(), player.getY() + 1, player.getZ(), 20);
                player.teleportTo(feet.getX() + 0.5, feet.getY(), feet.getZ() + 0.5);
                puff(level, ParticleTypes.POOF, player.getX(), player.getY() + 1, player.getZ(), 20);
                sound(level, player.getX(), player.getY(), player.getZ(), SoundEvents.ENDERMAN_TELEPORT, 1.5f);
                return true;
            }
        }
        fail(player, "No wall to paint a door on.");
        return false;
    }

    /** A huge anvil flattens the target you are looking at. */
    private static boolean anvilDrop(ServerLevel level, Player player) {
        LivingEntity target = findTarget(level, player, 30.0);
        if (target == null) {
            fail(player, "No target.");
            return false;
        }
        target.hurt(player.damageSources().playerAttack(player), 40.0f);
        target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 50, 9));
        target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 50, 2));
        puff(level, ParticleTypes.CAMPFIRE_COSY_SMOKE, target.getX(), target.getY() + 0.2, target.getZ(), 40);
        puff(level, ParticleTypes.EXPLOSION, target.getX(), target.getY() + 0.5, target.getZ(), 6);
        sound(level, target.getX(), target.getY(), target.getZ(), SoundEvents.ANVIL_LAND, 0.8f);
        return true;
    }

    /** A bundle of dynamite with an unreasonably big blast, where you are looking. */
    private static boolean dynamite(ServerLevel level, Player player) {
        HitResult hit = player.pick(24.0, 0.0f, false);
        Vec3 pos = hit.getLocation();
        if (pos.distanceTo(player.getEyePosition()) < 4.0) {
            fail(player, "Too close!");
            return false;
        }
        level.explode(player, pos.x, pos.y, pos.z, 4.0f, Level.ExplosionInteraction.NONE);
        return true;
    }

    /** A spring-loaded glove with ricochet-ish knockback. */
    private static boolean boxingGlove(ServerLevel level, Player player) {
        LivingEntity target = findTarget(level, player, 15.0);
        if (target == null) {
            fail(player, "No target.");
            return false;
        }
        Vec3 look = player.getLookAngle();
        target.hurt(player.damageSources().playerAttack(player), 12.0f);
        target.setDeltaMovement(look.scale(3.0).add(0, 0.6, 0));
        target.hurtMarked = true;
        puff(level, ParticleTypes.CRIT, target.getX(), target.getY() + 1, target.getZ(), 30);
        sound(level, target.getX(), target.getY(), target.getZ(), SoundEvents.SLIME_SQUISH, 0.6f);
        return true;
    }

    /** Float in the air for a moment, cartoon-style. */
    private static boolean gravityGag(ServerLevel level, Player player) {
        player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 80, 0));
        player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 80, 1));
        player.setDeltaMovement(player.getDeltaMovement().add(0, 0.7, 0));
        player.hurtMarked = true;
        player.fallDistance = 0;
        puff(level, ParticleTypes.CLOUD, player.getX(), player.getY(), player.getZ(), 20);
        sound(level, player.getX(), player.getY(), player.getZ(), SoundEvents.FIREWORK_ROCKET_LAUNCH, 1.2f);
        return true;
    }

    /** Scroll the world sideways: you dodge one way, nearby enemies get yanked the other. */
    private static boolean fourthWall(ServerLevel level, Player player) {
        Vec3 look = player.getLookAngle();
        Vec3 right = new Vec3(-look.z, 0, look.x);
        if (right.lengthSqr() < 1.0E-4) {
            right = new Vec3(1, 0, 0);
        }
        right = right.normalize();

        // Try right first, then left.
        Vec3 chosen = null;
        for (int s = 1; s >= -1; s -= 2) {
            Vec3 side = right.scale(s);
            BlockPos feet = BlockPos.containing(
                    player.getX() + side.x * 6, player.getY(), player.getZ() + side.z * 6);
            if (isFree(level, feet) && hasFloor(level, feet)) {
                chosen = side;
                break;
            }
        }
        if (chosen == null) {
            fail(player, "No room to scroll.");
            return false;
        }

        AABB area = player.getBoundingBox().inflate(8.0);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, area,
                x -> x != player && x.isAlive())) {
            e.setDeltaMovement(chosen.scale(-2.5).add(0, 0.4, 0));
            e.hurtMarked = true;
            e.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 100, 0));
        }

        puff(level, ParticleTypes.POOF, player.getX(), player.getY() + 1, player.getZ(), 25);
        player.teleportTo(player.getX() + chosen.x * 6, player.getY(), player.getZ() + chosen.z * 6);
        puff(level, ParticleTypes.POOF, player.getX(), player.getY() + 1, player.getZ(), 25);
        sound(level, player.getX(), player.getY(), player.getZ(), SoundEvents.ENDERMAN_TELEPORT, 0.6f);
        return true;
    }

    /** The domain: everything nearby is flattened, slowed and crushed by the closing iris. */
    private static boolean domain(ServerLevel level, Player player) {
        double radius = 10.0;
        AABB area = player.getBoundingBox().inflate(radius);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, area,
                x -> x != player && x.isAlive() && x.distanceTo(player) <= radius)) {
            e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 3));
            e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 1));
            e.hurt(player.damageSources().playerAttack(player), 20.0f);
        }
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 100, 3));

        // Closing iris: rings of cloud that shrink inward.
        for (int ring = 0; ring < 4; ring++) {
            double r = radius - ring * 2.5;
            for (int a = 0; a < 40; a++) {
                double ang = a * (Math.PI * 2 / 40);
                level.sendParticles(ParticleTypes.CLOUD,
                        player.getX() + Math.cos(ang) * r, player.getY() + 0.3,
                        player.getZ() + Math.sin(ang) * r, 1, 0, 0.1, 0, 0.0);
            }
        }
        sound(level, player.getX(), player.getY(), player.getZ(), SoundEvents.ANVIL_LAND, 0.5f);
        return true;
    }
}
