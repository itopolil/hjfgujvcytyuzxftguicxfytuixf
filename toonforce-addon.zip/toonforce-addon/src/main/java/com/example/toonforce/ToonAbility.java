package com.example.toonforce;

/** The gags in the Toon Force kit. Cost is cursed energy; cooldown is in ticks (20 = 1s). */
public enum ToonAbility {
    PAINTED_DOOR("Painted Door", "KNOCK KNOCK!", 15, 30),
    ANVIL_DROP("Anvil Drop", "CRASH!", 20, 60),
    DYNAMITE("Dynamite Bundle", "KABOOM!", 25, 80),
    BOXING_GLOVE("Boxing Glove", "BOING!", 15, 40),
    GRAVITY_GAG("Gravity Gag", "WHEEE!", 10, 100),
    FOURTH_WALL("Fourth Wall Break", "*RIIIIP*", 30, 120),
    DOMAIN("That's All Folks", "THAT'S ALL FOLKS!", 80, 1200);

    public final String displayName;
    public final String comicWord;
    public final int cost;
    public final int cooldown;

    ToonAbility(String displayName, String comicWord, int cost, int cooldown) {
        this.displayName = displayName;
        this.comicWord = comicWord;
        this.cost = cost;
        this.cooldown = cooldown;
    }
}
